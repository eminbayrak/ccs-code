#!/usr/bin/env bun
import { Command } from "commander";
import React from "react";
import { render } from "ink";
import figlet from "figlet";
import gradient from "gradient-string";
import { App } from "./components/App";
import { getGlobalHookEngine } from "./hooks/engine.js";
import { loadHooksFromProject } from "./hooks/loader.js";
import { resolve } from "path";

const program = new Command();

program
  .name("my-cli")
  .description("A custom AI CLI assistant inspired by Claude Code")
  .version("0.1.0")
  .option("-p, --prompt <prompt>", "Initial prompt to start the session")
  .option("--compact", "Use a compact startup banner")
  .action((options) => {
    // Initialize hooks engine
    const hookEngine = getGlobalHookEngine();
    const projectRoot = resolve(process.cwd());
    loadHooksFromProject(projectRoot, hookEngine);

    const compactFromEnv = ["1", "true", "yes"].includes(
      String(process.env.CCS_COMPACT_BANNER ?? "").toLowerCase(),
    );
    const useCompactBanner = Boolean(options.compact || compactFromEnv);

    if (useCompactBanner) {
      console.log(gradient.atlas("CCS CODE"));
      console.log("\n");
    } else {
      console.clear();
      const mascot = figlet.textSync("CCS CODE", { font: "ANSI Shadow" });
      console.log(gradient.pastel.multiline(mascot));
      console.log("\n");
    }

    // Replaces the terminal view with our Ink React App
    render(<App initialPrompt={options.prompt} />);
  });

program.parse();
