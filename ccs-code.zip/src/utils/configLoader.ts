import { promises as fs } from "fs";
import { join } from "path";
import { homedir } from "os";

export type ConfigFile = {
  path: string;
  name: string;
  priority: "global" | "project" | "rules";
};

export type CapabilityConfigFile = {
  path: string;
  name: string;
  category: "tools" | "connectors" | "agents";
};

/**
 * Mirrors the Claude Code claudemd.ts discovery hierarchy exactly:
 *
 * Priority (lowest → highest):
 *   1. ~/.ccs/CCS.md         — Global personal instructions (all projects)
 *   2. ./CCS.md              — Project-level instructions
 *   3. ./.ccs/rules/*.md     — Granular per-project rules (highest priority)
 *
 * Files with higher priority are injected later into the system prompt,
 * so the LLM pays more attention to them.
 */
export async function loadInstructions(cwd: string): Promise<ConfigFile[]> {
  const instructions: ConfigFile[] = [];

  // 1. Global personal instructions (~/.ccs/CCS.md)
  try {
    const globalPath = join(homedir(), ".ccs", "CCS.md");
    await fs.access(globalPath);
    instructions.push({ path: globalPath, name: "~/.ccs/CCS.md", priority: "global" });
  } catch {
    // Not present — fine, it's optional
  }

  // 2. Project-level CCS.md (./CCS.md)
  try {
    const projectPath = join(cwd, "CCS.md");
    await fs.access(projectPath);
    instructions.push({ path: projectPath, name: "CCS.md", priority: "project" });
  } catch {
    // Not present — fine
  }

  // 3. Granular rules (.ccs/rules/*.md) — highest priority
  try {
    const rulesDir = join(cwd, ".ccs", "rules");
    const entries = await fs.readdir(rulesDir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isFile() && entry.name.endsWith(".md")) {
        instructions.push({
          path: join(rulesDir, entry.name),
          name: `.ccs/rules/${entry.name}`,
          priority: "rules",
        });
      }
    }
  } catch {
    // Rules dir doesn't exist — fine
  }

  return instructions;
}

/**
 * Reads all discovered instruction files and merges their content
 * in priority order (lowest first, highest last = highest attention from LLM).
 */
export async function buildSystemPrompt(cwd: string): Promise<string> {
  const files = await loadInstructions(cwd);
  const parts: string[] = [];

  for (const file of files) {
    try {
      const content = await fs.readFile(file.path, "utf-8");
      if (content.trim()) {
        parts.push(`# Instructions from ${file.name}\n\n${content.trim()}`);
      }
    } catch {
      // Skip unreadable files silently
    }
  }

  return parts.join("\n\n---\n\n");
}

// Skills discovery (unchanged)
export async function loadSkills(cwd: string): Promise<ConfigFile[]> {
  const skills: ConfigFile[] = [];

  try {
    const skillsDir = join(cwd, ".ccs", "skills");
    const entries = await fs.readdir(skillsDir, { withFileTypes: true });

    for (const entry of entries) {
      if (entry.isFile() && entry.name.endsWith(".md")) {
        skills.push({
          path: join(skillsDir, entry.name),
          name: entry.name,
          priority: "project",
        });
      }
      if (entry.isDirectory()) {
        try {
          const skillYmlPath = join(skillsDir, entry.name, "SKILL.md");
          await fs.access(skillYmlPath);
          skills.push({
            path: skillYmlPath,
            name: `${entry.name}/SKILL.md`,
            priority: "project",
          });
        } catch {
          // No SKILL.md in this directory
        }
      }
    }
  } catch {
    // Skills dir doesn't exist
  }

  return skills;
}

async function loadCapabilityFiles(
  cwd: string,
  dirName: "tools" | "connectors" | "agents",
): Promise<CapabilityConfigFile[]> {
  const files: CapabilityConfigFile[] = [];

  try {
    const dir = join(cwd, ".ccs", dirName);
    const entries = await fs.readdir(dir, { withFileTypes: true });

    for (const entry of entries) {
      if (entry.isFile() && (entry.name.endsWith(".json") || entry.name.endsWith(".md"))) {
        files.push({
          path: join(dir, entry.name),
          name: `.ccs/${dirName}/${entry.name}`,
          category: dirName,
        });
      }
    }
  } catch {
    // Directory does not exist yet.
  }

  return files;
}

export async function loadToolDefinitions(cwd: string): Promise<CapabilityConfigFile[]> {
  return loadCapabilityFiles(cwd, "tools");
}

export async function loadConnectorDefinitions(cwd: string): Promise<CapabilityConfigFile[]> {
  return loadCapabilityFiles(cwd, "connectors");
}

export async function loadAgentDefinitions(cwd: string): Promise<CapabilityConfigFile[]> {
  return loadCapabilityFiles(cwd, "agents");
}
