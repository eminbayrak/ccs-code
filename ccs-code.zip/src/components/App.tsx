import React, { useState, useEffect, useRef, useCallback } from "react";
import { Text, Box, useApp, useInput, Static } from "ink";
import TextInput from "ink-text-input";
import { randomUUID } from "crypto";
import { promises as fs } from "fs";
import { join } from "path";
import { CCSSpinner } from "./animations/CCSSpinner";
import { AgentProgressLine } from "./animations/AgentProgressLine";
import { ShimmerText } from "./animations/ShimmerText";
import { BuddySprite } from "./animations/BuddySprite";
import { StatusBar } from "./StatusBar";
import { HelpMenu } from "./HelpMenu";
import { SuggestionList, type SuggestionItem } from "./SuggestionList";
import {
  loadInstructions,
  loadSkills,
  buildSystemPrompt,
  type ConfigFile,
} from "../utils/configLoader";
import { getProjectFiles, filterFiles } from "../utils/filePicker";
import { createProvider } from "../llm/index";
import type { LLMProvider } from "../llm/index";
import type { Message } from "../llm/providers/base";
import { Orchestrator } from "../orchestrator/index";
import {
  getPendingApprovals,
  resolveApproval,
} from "../governance/approvals";
import { listAgentRuns } from "../tasks/agentRuns";
import type { PermissionMode } from "../governance/permissions";
import { hooksCommandHandler } from "../commands/hooks";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type UIMessage = {
  id: string;                    // unique key for Static
  role: "user" | "assistant";
  content: string;
};

function createUIMessage(role: UIMessage["role"], content: string): UIMessage {
  return {
    id: randomUUID(),
    role,
    content,
  };
}

type ToolExecution = {
  id: string;
  name: string;
  isComplete: boolean;
};

type SuggestionMode = "file" | "command" | null;

// ---------------------------------------------------------------------------
// Slash Commands registry
// ---------------------------------------------------------------------------

const SLASH_COMMANDS: SuggestionItem[] = [
  { id: "clear", label: "/clear", description: "Clear conversation history" },
  { id: "skills", label: "/skills", description: "List loaded .ccs skills" },
  { id: "model", label: "/model", description: "Show active model" },
  { id: "approvals", label: "/approvals", description: "List pending approvals" },
  { id: "approve", label: "/approve <id>", description: "Approve a pending action" },
  { id: "reject", label: "/reject <id>", description: "Reject a pending action" },
  { id: "tasks", label: "/tasks", description: "List background agent tasks" },
  { id: "mode", label: "/mode <default|plan|permissive>", description: "Set permission mode" },
  { id: "hooks", label: "/hooks <list|enable|disable|clear>", description: "Manage event hooks" },
  { id: "help", label: "/help", description: "Toggle keyboard shortcuts" },
  { id: "exit", label: "/exit", description: "Exit CCS Code" },
];

function filterCommands(query: string): SuggestionItem[] {
  const q = query.toLowerCase();
  return SLASH_COMMANDS.filter((c) => c.label.includes(q));
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Detect the last @ trigger and extract the query after it. */
function detectAtTrigger(value: string): { triggerStart: number; query: string; } | null {
  const idx = value.lastIndexOf("@");
  if (idx === -1) return null;
  const after = value.slice(idx + 1);
  if (after.includes(" ")) return null; // space after @ = done typing
  return { triggerStart: idx, query: after };
}

/** Detect a / trigger at the start of the line. */
function detectSlashTrigger(value: string): { query: string; } | null {
  if (!value.startsWith("/")) return null;
  const after = value.slice(1);
  if (after.includes(" ")) return null;
  return { query: after };
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function App({ initialPrompt }: { initialPrompt?: string; }) {
  const { exit } = useApp();
  const terminalWidth = process.stdout.columns ?? 120;

  // Chat state
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [input, setInput] = useState("");

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [isStalled, setIsStalled] = useState(false);
  const [activeTools, setActiveTools] = useState<ToolExecution[]>([]);
  const [helpOpen, setHelpOpen] = useState(false);

  // Environment
  const [instructions, setInstructions] = useState<ConfigFile[]>([]);
  const [skills, setSkills] = useState<ConfigFile[]>([]);
  const [activeModel, setActiveModel] = useState("Loading...");
  const [permissionMode, setPermissionMode] = useState<PermissionMode>("default");

  // Suggestion state
  const [suggestionMode, setSuggestionMode] = useState<SuggestionMode>(null);
  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([]);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [atTriggerStart, setAtTriggerStart] = useState(-1);
  const [inputKey, setInputKey] = useState(0); // bumped to force TextInput remount → cursor reset

  // Injected files (path → content)
  const injectedFilesRef = useRef<Map<string, string>>(new Map());

  // LLM provider
  const providerRef = useRef<LLMProvider | null>(null);
  const orchestratorRef = useRef<Orchestrator | null>(null);
  const systemPromptRef = useRef<string>("");
  const allFilesRef = useRef<{ path: string; label: string; }[]>([]);

  // ---------------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------------

  useEffect(() => {
    async function bootEngine() {
      const cwd = process.cwd();
      const [loadedInstructions, loadedSkills, systemPrompt, projectFiles] =
        await Promise.all([
          loadInstructions(cwd),
          loadSkills(cwd),
          buildSystemPrompt(cwd),
          getProjectFiles(cwd),
        ]);

      setInstructions(loadedInstructions);
      setSkills(loadedSkills);
      systemPromptRef.current = systemPrompt;
      allFilesRef.current = projectFiles;

      try {
        const provider = await createProvider();
        providerRef.current = provider;
        orchestratorRef.current = new Orchestrator(provider);
        setActiveModel(provider.name);
        setMessages([
          createUIMessage(
            "assistant",
            `CCS Code ready. Connected to **${provider.name}**. ${loadedInstructions.length} instruction file(s) loaded.`,
          ),
        ]);
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        setActiveModel("Not connected");
        setMessages([
          createUIMessage(
            "assistant",
            `⚠️  No LLM provider configured. Check .ccs/config.json and .env.\n\nError: ${msg}`,
          ),
        ]);
      }
    }
    bootEngine();
  }, []);

  // ---------------------------------------------------------------------------
  // Input change — detect @ and / triggers
  // ---------------------------------------------------------------------------

  const handleInputChange = useCallback(
    async (value: string) => {
      setInput(value);
      setSelectedIdx(0);

      // Claude-like help behavior: show help only while the input is exactly '?'.
      const isHelpTrigger = value.trim() === "?";
      if (!isProcessing) {
        if (isHelpTrigger && !helpOpen) setHelpOpen(true);
        if (!isHelpTrigger && helpOpen) setHelpOpen(false);
      }

      // --- @ file trigger ---
      const atResult = detectAtTrigger(value);
      if (atResult) {
        setSuggestionMode("file");
        setAtTriggerStart(atResult.triggerStart);
        const matched = filterFiles(allFilesRef.current, atResult.query);
        setSuggestions(matched.map((f) => ({ id: f.path, label: f.path })));
        return;
      }

      // --- / command trigger ---
      const slashResult = detectSlashTrigger(value);
      if (slashResult) {
        setSuggestionMode("command");
        setSuggestions(filterCommands(slashResult.query));
        return;
      }

      // No trigger
      setSuggestionMode(null);
      setSuggestions([]);
    },
    [helpOpen, isProcessing],
  );

  // ---------------------------------------------------------------------------
  // Keyboard: navigate suggestions or toggle helpers
  // ---------------------------------------------------------------------------

  useInput((inputChar, key) => {
    if (key.escape && helpOpen) {
      setHelpOpen(false);
      return;
    }

    if (!suggestionMode) return;

    // Esc → close suggestion list
    if (key.escape) {
      setSuggestionMode(null);
      setSuggestions([]);
      return;
    }

    // ↑ / ↓ navigation
    if (key.upArrow) {
      setSelectedIdx((i) => Math.max(0, i - 1));
      return;
    }
    if (key.downArrow) {
      setSelectedIdx((i) => Math.min(suggestions.length - 1, i + 1));
      return;
    }

    // Tab → accept selected
    if (key.tab) {
      applySuggestion(suggestions[selectedIdx]);
    }
  });

  // ---------------------------------------------------------------------------
  // Apply a selected suggestion
  // ---------------------------------------------------------------------------

  const applySuggestion = useCallback(
    async (item: SuggestionItem | undefined) => {
      if (!item) return;

      if (suggestionMode === "file") {
        // Replace @<query> with @filename token and a trailing space
        const before = input.slice(0, atTriggerStart);
        const newInput = `${before}@${item.label} `;
        setInput(newInput);
        setInputKey((k) => k + 1); // Force TextInput remount so cursor jumps to end

        // Read and cache the file content for injection
        try {
          const content = await fs.readFile(
            join(process.cwd(), item.label),
            "utf-8",
          );
          injectedFilesRef.current.set(item.label, content);
        } catch {
          // Silently ignore unreadable files
        }
      } else if (suggestionMode === "command") {
        // Commands that require arguments should populate the input for editing.
        if (item.id === "approve" || item.id === "reject" || item.id === "mode") {
          setInput(`/${item.id} `);
          setInputKey((k) => k + 1);
        } else {
          executeSlashCommand(item.id);
          setInput("");
        }
      }

      setSuggestionMode(null);
      setSuggestions([]);
    },
    [suggestionMode, input, atTriggerStart],
  );

  // ---------------------------------------------------------------------------
  // Execute slash commands
  // ---------------------------------------------------------------------------

  const executeSlashCommand = (raw: string) => {
    const [id, ...args] = raw.trim().split(/\s+/);
    const arg = args.join(" ").trim();

    switch (id) {
      case "clear":
        setMessages([]);
        injectedFilesRef.current.clear();
        break;
      case "help":
        setHelpOpen((p) => !p);
        break;
      case "model":
        setMessages((prev) => [
          ...prev,
          createUIMessage(
            "assistant",
            `Active model: **${activeModel}**\nPermission mode: **${permissionMode}**\nChange model via .ccs/config.json`,
          ),
        ]);
        break;
      case "approvals": {
        const pending = getPendingApprovals();
        const content = pending.length === 0
          ? "No pending approvals."
          : [
            `Pending approvals (${pending.length}):`,
            ...pending.map((a) => `• ${a.id} | ${a.toolName} | ${a.riskClass} | ${a.rationale}`),
          ].join("\n");
        setMessages((prev) => [...prev, createUIMessage("assistant", content)]);
        break;
      }
      case "approve": {
        if (!arg) {
          setMessages((prev) => [...prev, createUIMessage("assistant", "Usage: /approve <approval-id>")]);
          break;
        }
        const resolved = resolveApproval(arg, "approved");
        setMessages((prev) => [
          ...prev,
          createUIMessage(
            "assistant",
            resolved
              ? `Approved ${arg} for ${resolved.toolName}.`
              : `Approval id not found: ${arg}`,
          ),
        ]);
        break;
      }
      case "reject": {
        if (!arg) {
          setMessages((prev) => [...prev, createUIMessage("assistant", "Usage: /reject <approval-id>")]);
          break;
        }
        const resolved = resolveApproval(arg, "rejected");
        setMessages((prev) => [
          ...prev,
          createUIMessage(
            "assistant",
            resolved
              ? `Rejected ${arg} for ${resolved.toolName}.`
              : `Approval id not found: ${arg}`,
          ),
        ]);
        break;
      }
      case "tasks": {
        const runs = listAgentRuns();
        const content = runs.length === 0
          ? "No agent tasks yet."
          : [
            `Agent tasks (${runs.length}):`,
            ...runs.map((r) => `• ${r.id} | ${r.agentType} | ${r.status}${r.error ? ` | error: ${r.error}` : ""}`),
          ].join("\n");
        setMessages((prev) => [...prev, createUIMessage("assistant", content)]);
        break;
      }
      case "mode": {
        const mode = arg as PermissionMode;
        if (mode !== "default" && mode !== "plan" && mode !== "permissive") {
          setMessages((prev) => [...prev, createUIMessage("assistant", "Usage: /mode <default|plan|permissive>")]);
          break;
        }
        setPermissionMode(mode);
        setMessages((prev) => [...prev, createUIMessage("assistant", `Permission mode set to ${mode}.`)]);
        break;
      }
      case "skills":
        setMessages((prev) => [
          ...prev,
          createUIMessage(
            "assistant",
            skills.length > 0
              ? `Loaded skills (${skills.length}):\n${skills.map((s) => `• ${s.name}`).join("\n")}`
              : "No skills loaded. Create `.ccs/skills/*.md` files.",
          ),
        ]);
        break;
      case "hooks": {
        const output = hooksCommandHandler(args);
        setMessages((prev) => [...prev, createUIMessage("assistant", output)]);
        break;
      }
      case "exit":
        exit();
        break;
      default:
        setMessages((prev) => [...prev, createUIMessage("assistant", `Unknown command: /${id}`)]);
        break;
    }
  };

  // ---------------------------------------------------------------------------
  // Submit
  // ---------------------------------------------------------------------------

  const handleSubmit = useCallback(
    (value: string) => {
      // If a suggestion is highlighted, Tab/Enter should apply it, not submit
      if (suggestionMode && suggestions.length > 0) {
        applySuggestion(suggestions[selectedIdx]);
        return;
      }

      const trimmed = value.trim();
      if (!trimmed) return;

      // Plain slash commands typed and submitted
      if (trimmed.startsWith("/")) {
        executeSlashCommand(trimmed.slice(1));
        setInput("");
        return;
      }

      // Build the final message: inline content from injected @files
      let finalContent = trimmed;
      const injected = injectedFilesRef.current;
      if (injected.size > 0) {
        const fileBlocks = Array.from(injected.entries())
          .map(([path, content]) =>
            `\n\n[File: ${path}]\n\`\`\`\n${content.slice(0, 8000)}\n\`\`\``,
          )
          .join("");
        finalContent = trimmed + fileBlocks;
        injected.clear();
      }

      const userMsg: UIMessage = createUIMessage("user", trimmed); // display without file blobs
      setMessages((prev) => [...prev, userMsg]);
      setInput("");

      // Send the full content (including file blobs) to the LLM
      const history: Message[] = [
        ...messages,
        { role: "user", content: finalContent },
      ];
      sendToLLM(history);
    },
    [suggestionMode, suggestions, selectedIdx, messages, skills, activeModel],
  );

  // ---------------------------------------------------------------------------
  // LLM call
  // ---------------------------------------------------------------------------

  const sendToLLM = async (history: Message[]) => {
    const provider = providerRef.current;
    if (!provider) {
      setMessages((prev) => [
        ...prev,
        createUIMessage("assistant", "⚠️  No LLM provider. Check .ccs/config.json and .env."),
      ]);
      return;
    }

    setIsProcessing(true);
    setIsStalled(false);
    setActiveTools([{ id: "1", name: `Sending to ${provider.name}...`, isComplete: false }]);

    const stallTimer = setTimeout(() => setIsStalled(true), 10_000);

    try {
      const orchestrator = orchestratorRef.current;
      const output = orchestrator
        ? await orchestrator.run({
          cwd: process.cwd(),
          history,
          systemPrompt: systemPromptRef.current || "",
          permissionMode,
        })
        : {
          response: await provider.chat(history, systemPromptRef.current || undefined),
          usedTools: [],
          startedAgentRunIds: [],
          logs: [],
        };

      clearTimeout(stallTimer);
      if (output.usedTools.length > 0) {
        setActiveTools(
          output.usedTools.map((toolName, index) => ({
            id: `${index + 1}`,
            name: `Executed ${toolName}`,
            isComplete: true,
          })),
        );
      } else {
        setActiveTools((t) => t.map((tool) => ({ ...tool, isComplete: true })));
      }

      setTimeout(() => {
        setMessages((prev) => [...prev, createUIMessage("assistant", output.response)]);
        setActiveTools([]);
        setIsProcessing(false);
        setIsStalled(false);
      }, 300);
    } catch (e) {
      clearTimeout(stallTimer);
      const errorMsg = e instanceof Error ? e.message : String(e);
      setActiveTools([]);
      setIsProcessing(false);
      setIsStalled(false);
      setMessages((prev) => [...prev, createUIMessage("assistant", `❌ Error: ${errorMsg}`)]);
    }
  };

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      {/* Header */}
      <Box
        flexDirection="row"
        justifyContent="space-between"
        marginBottom={1}
        borderBottom={false}
      >
        <Box
          borderStyle="round"
          borderColor="gray"
          paddingX={1}
          height={3}
          justifyContent="center"
        >
          <Text bold color="yellow">CCS CODE</Text>
        </Box>
        <BuddySprite species="cat" isProcessing={isProcessing} />
      </Box>

      {/* Messages — rendered into terminal scrollback via Static */}
      <Static items={messages}>
        {(msg) => (
          <Box key={msg.id} flexDirection="column" marginBottom={1} paddingX={2}>
            <Box>
              {msg.role === "user" ? (
                <Text bold color="cyan">❯ You</Text>
              ) : (
                <Text bold color="yellow">❖ CCS</Text>
              )}
            </Box>
            <Box paddingLeft={2}>
              {msg.role === "assistant" ? (
                <ShimmerText text={msg.content} />
              ) : (
                <Text color="white">{msg.content}</Text>
              )}
            </Box>
          </Box>
        )}
      </Static>

      {/* Processing */}
      {isProcessing && (
        <Box flexDirection="column" marginBottom={1} marginLeft={2}>
          <Box>
            <CCSSpinner
              label={isStalled ? " CCS is thinking deeply..." : " CCS is evaluating..."}
              isStalled={isStalled}
            />
          </Box>
          {activeTools.map((tool) => (
            <Box marginLeft={2} key={tool.id}>
              <AgentProgressLine taskName={tool.name} isComplete={tool.isComplete} />
            </Box>
          ))}
        </Box>
      )}

      {/* Input area */}
      {!isProcessing && (
        <Box flexDirection="column" marginTop={1}>
          {/* Suggestion list appears above the input */}
          {suggestionMode && suggestions.length > 0 && (
            <SuggestionList
              items={suggestions}
              selectedIndex={selectedIdx}
              mode={suggestionMode}
            />
          )}

          {/* Text input */}
          <Box borderStyle="round" borderColor={suggestionMode ? "cyan" : "white"} paddingX={1}>
            <Box marginRight={1}>
              <Text bold color="cyan">❯</Text>
            </Box>
            <TextInput
              key={inputKey}
              value={input}
              onChange={handleInputChange}
              onSubmit={handleSubmit}
              placeholder="Type a message, @ to reference a file, / for commands"
            />
          </Box>

          {/* Footer: Help or StatusBar */}
          <Box paddingBottom={1}>
            {helpOpen ? (
              <HelpMenu terminalWidth={terminalWidth} />
            ) : (
              <StatusBar
                workspacePath={process.cwd()}
                sandboxStatus={`mode: ${permissionMode}`}
                activeModel={activeModel}
                instructionsCount={instructions.length}
                skillsCount={skills.length}
                terminalWidth={terminalWidth}
              />
            )}
          </Box>
        </Box>
      )}
    </Box>
  );
}
