import React from "react";
import { Box, Text } from "ink";

type StatusBarProps = {
  workspacePath: string;
  sandboxStatus: string;
  activeModel: string;
  instructionsCount: number;
  skillsCount: number;
  terminalWidth?: number;
};

export function StatusBar({ workspacePath, sandboxStatus, activeModel, instructionsCount, skillsCount, terminalWidth }: StatusBarProps) {
  // Extract just the last folder or display '/' for root style depending on what we want
  const displayDir = workspacePath.split('/').pop() || '/';
  const width = terminalWidth ?? process.stdout.columns ?? 120;
  const isNarrow = width < 92;

  return (
    <Box flexDirection="column" marginTop={1} paddingX={1}>
      {/* Top Hints Row */}
      <Box flexDirection={isNarrow ? "column" : "row"} justifyContent="space-between" marginBottom={1}>
        <Text color="gray">Shift+Tab to accept edits</Text>
        <Text color="gray">{instructionsCount} CCS.md files • {skillsCount} skills</Text>
      </Box>

      {/* Main Status Row */}
      <Box flexDirection={isNarrow ? "column" : "row"} justifyContent="space-between">
        {/* Column 1: Workspace */}
        <Box flexDirection="column" width={isNarrow ? undefined : "40%"} marginBottom={isNarrow ? 1 : 0}>
          <Text color="gray">workspace (/directory)</Text>
          <Text color="whiteBright">{displayDir}</Text>
        </Box>

        {/* Column 2: Sandbox */}
        <Box flexDirection="column" width={isNarrow ? undefined : "30%"} marginBottom={isNarrow ? 1 : 0}>
          <Text color="gray">sandbox</Text>
          <Text color="yellow">{sandboxStatus}</Text>
        </Box>

        {/* Column 3: Model */}
        <Box flexDirection="column" width={isNarrow ? undefined : "30%"} alignItems={isNarrow ? "flex-start" : "flex-end"}>
          <Text color="gray">/model</Text>
          <Text color="whiteBright">{activeModel}</Text>
        </Box>
      </Box>
    </Box>
  );
}
