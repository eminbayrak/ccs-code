import React, { useState, useEffect } from "react";
import { Text } from "ink";

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

// Recreates the smooth stall interpolation mechanism
export function CCSSpinner({ label, isStalled = false }: { label: string, isStalled?: boolean }) {
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setFrame((f) => (f + 1) % SPINNER_FRAMES.length);
    }, 80);
    return () => clearInterval(timer);
  }, []);

  return (
    <Text color={isStalled ? "red" : "yellow"}>
      {SPINNER_FRAMES[frame]} <Text color={isStalled ? "yellow" : "gray"}>{label}</Text>
    </Text>
  );
}
