import React, { useState, useEffect } from "react";
import { Text, Box } from "ink";

const FULL_BLOCK = "█";
const EMPTY_BLOCK = "░";
const BAR_LENGTH = 15;

export function AgentProgressLine({ taskName, isComplete = false }: { taskName: string; isComplete?: boolean }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isComplete) {
      setProgress(100);
      return;
    }
    // Simulate gradual progress
    const timer = setInterval(() => {
      setProgress((p) => {
        if (p >= 95) return p;
        return p + Math.floor(Math.random() * 5) + 1;
      });
    }, 200);

    return () => clearInterval(timer);
  }, [isComplete]);

  const filledCount = Math.round((progress / 100) * BAR_LENGTH);
  const emptyCount = BAR_LENGTH - filledCount;

  const bar = FULL_BLOCK.repeat(filledCount) + EMPTY_BLOCK.repeat(emptyCount);

  return (
    <Box flexDirection="row">
      <Text color="gray">{"[ "}</Text>
      <Text color={isComplete ? "green" : "cyan"}>{bar}</Text>
      <Text color="gray">{" ] "}</Text>
      <Text color="gray">{isComplete ? "✓" : "⟳"} </Text>
      <Text color={isComplete ? "gray" : "white"}>{taskName}</Text>
    </Box>
  );
}
