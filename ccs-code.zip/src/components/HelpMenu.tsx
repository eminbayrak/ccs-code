import React from "react";
import { Box, Text } from "ink";
import { platform } from "os";

/**
 * Mirrors Claude Code's compact 3-column dimColor layout.
 * Only shows shortcuts that are actually implemented.
 */
export function HelpMenu({ terminalWidth }: { terminalWidth?: number; }) {
  const isWindows = platform() === "win32";
  const width = terminalWidth ?? process.stdout.columns ?? 120;
  const isNarrow = width < 100;

  return (
    <Box paddingX={2} flexDirection={isNarrow ? "column" : "row"} gap={1} marginTop={1}>
      {/* Column 1: Prompt prefixes */}
      <Box flexDirection="column" width={28}>
        <Box><Text color="gray">@ to reference a file</Text></Box>
        <Box><Text color="gray">/ for commands</Text></Box>
        <Box><Text color="gray">? to toggle this menu</Text></Box>
      </Box>

      {/* Column 2: Input navigation */}
      <Box flexDirection="column" width={35}>
        <Box><Text color="gray">↑↓ to navigate suggestions</Text></Box>
        <Box><Text color="gray">Tab to accept suggestion</Text></Box>
        <Box><Text color="gray">Esc to cancel suggestion</Text></Box>
        <Box><Text color="gray">Enter to send message</Text></Box>
      </Box>

      {/* Column 3: Slash commands */}
      <Box flexDirection="column">
        <Box><Text color="gray">/clear — clear history</Text></Box>
        <Box><Text color="gray">/skills — list skills</Text></Box>
        <Box><Text color="gray">/model — show active model + mode</Text></Box>
        <Box><Text color="gray">/approvals — list pending approvals</Text></Box>
        <Box><Text color="gray">/approve &lt;id&gt; — approve action</Text></Box>
        <Box><Text color="gray">/reject &lt;id&gt; — reject action</Text></Box>
        <Box><Text color="gray">/tasks — list background agent tasks</Text></Box>
        <Box><Text color="gray">/mode &lt;default|plan|permissive&gt;</Text></Box>
        <Box><Text color="gray">/hooks &lt;list|debug|stats&gt; Phase 2</Text></Box>
        <Box><Text color="gray">/help — toggle shortcuts</Text></Box>
        <Box><Text color="gray">/exit — exit CCS Code</Text></Box>
        {!isWindows && <Box><Text color="gray">ctrl+c — exit</Text></Box>}
      </Box>
    </Box>
  );
}
