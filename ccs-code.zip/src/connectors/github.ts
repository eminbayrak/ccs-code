import { z } from "zod";
import type { ConnectorAdapter } from "./base.js";
import type { ToolDescriptor } from "../capabilities/types.js";

const searchCodeInputSchema = z.object({
    query: z.string().min(1),
});

const listPullRequestsInputSchema = z.object({
    owner: z.string().min(1),
    repo: z.string().min(1),
    state: z.enum(["open", "closed", "all"]).default("open"),
    perPage: z.number().int().positive().max(100).default(10),
});

const summarizeOrgReposInputSchema = z.object({
    org: z.string().min(1),
    maxRepos: z.number().int().positive().max(1000).default(200),
    includeArchived: z.boolean().default(false),
});

export const githubConnector: ConnectorAdapter = {
    name: "github",
    getTools() {
        const tools: ToolDescriptor[] = [
            {
                id: "github.search_code",
                name: "github_search_code",
                kind: "tool",
                description: "Search code in GitHub using the authenticated user token.",
                riskClass: "read",
                inputSchema: searchCodeInputSchema,
                async handler(input) {
                    const parsed = searchCodeInputSchema.safeParse(input);
                    if (!parsed.success) {
                        return { status: "error", error: parsed.error.message };
                    }

                    const token = process.env.CCS_GITHUB_TOKEN;
                    if (!token) {
                        return {
                            status: "error",
                            error: "Missing CCS_GITHUB_TOKEN in environment.",
                        };
                    }

                    const url = new URL("https://api.github.com/search/code");
                    url.searchParams.set("q", parsed.data.query);
                    url.searchParams.set("per_page", "5");

                    const response = await fetch(url, {
                        headers: {
                            Accept: "application/vnd.github+json",
                            Authorization: `Bearer ${token}`,
                            "X-GitHub-Api-Version": "2022-11-28",
                        },
                    });

                    if (!response.ok) {
                        const text = await response.text();
                        return {
                            status: "error",
                            error: `GitHub search failed (${response.status}): ${text}`,
                        };
                    }

                    const json = await response.json();
                    return {
                        status: "success",
                        output: json,
                    };
                },
            },
            {
                id: "github.list_pull_requests",
                name: "github_list_pull_requests",
                kind: "tool",
                description: "List pull requests for a GitHub repository.",
                riskClass: "read",
                inputSchema: listPullRequestsInputSchema,
                async handler(input) {
                    const parsed = listPullRequestsInputSchema.safeParse(input);
                    if (!parsed.success) {
                        return { status: "error", error: parsed.error.message };
                    }

                    const token = process.env.CCS_GITHUB_TOKEN;
                    if (!token) {
                        return {
                            status: "error",
                            error: "Missing CCS_GITHUB_TOKEN in environment.",
                        };
                    }

                    const { owner, repo, state, perPage } = parsed.data;
                    const url = new URL(`https://api.github.com/repos/${owner}/${repo}/pulls`);
                    url.searchParams.set("state", state);
                    url.searchParams.set("per_page", String(perPage));

                    const response = await fetch(url, {
                        headers: {
                            Accept: "application/vnd.github+json",
                            Authorization: `Bearer ${token}`,
                            "X-GitHub-Api-Version": "2022-11-28",
                        },
                    });

                    if (!response.ok) {
                        const text = await response.text();
                        return {
                            status: "error",
                            error: `GitHub pull request list failed (${response.status}): ${text}`,
                        };
                    }

                    const json = await response.json();
                    return {
                        status: "success",
                        output: json,
                    };
                },
            },
            {
                id: "github.summarize_org_repos",
                name: "github_summarize_org_repos",
                kind: "tool",
                description:
                    "Scan repositories in a GitHub organization and return an aggregated portfolio summary.",
                riskClass: "read",
                inputSchema: summarizeOrgReposInputSchema,
                async handler(input) {
                    const parsed = summarizeOrgReposInputSchema.safeParse(input);
                    if (!parsed.success) {
                        return { status: "error", error: parsed.error.message };
                    }

                    const token = process.env.CCS_GITHUB_TOKEN;
                    if (!token) {
                        return {
                            status: "error",
                            error: "Missing CCS_GITHUB_TOKEN in environment.",
                        };
                    }

                    const headers = {
                        Accept: "application/vnd.github+json",
                        Authorization: `Bearer ${token}`,
                        "X-GitHub-Api-Version": "2022-11-28",
                    };

                    const { org, maxRepos, includeArchived } = parsed.data;
                    const repos: any[] = [];
                    let page = 1;
                    const perPage = 100;

                    while (repos.length < maxRepos) {
                        const url = new URL(`https://api.github.com/orgs/${org}/repos`);
                        url.searchParams.set("type", "all");
                        url.searchParams.set("sort", "updated");
                        url.searchParams.set("direction", "desc");
                        url.searchParams.set("per_page", String(perPage));
                        url.searchParams.set("page", String(page));

                        const response = await fetch(url, { headers });
                        if (!response.ok) {
                            const text = await response.text();
                            return {
                                status: "error",
                                error: `GitHub org repo scan failed (${response.status}): ${text}`,
                            };
                        }

                        const batch = await response.json();
                        if (!Array.isArray(batch) || batch.length === 0) {
                            break;
                        }

                        repos.push(...batch);
                        if (batch.length < perPage) {
                            break;
                        }
                        page += 1;
                    }

                    const limitedRepos = repos.slice(0, maxRepos);
                    const filteredRepos = includeArchived
                        ? limitedRepos
                        : limitedRepos.filter((repo) => !repo.archived);

                    const languageCounts: Record<string, number> = {};
                    const topicCounts: Record<string, number> = {};
                    const visibilityCounts: Record<string, number> = {};

                    for (const repo of filteredRepos) {
                        const language = repo.language || "Unknown";
                        languageCounts[language] = (languageCounts[language] ?? 0) + 1;

                        const visibility = repo.visibility || (repo.private ? "private" : "public");
                        visibilityCounts[visibility] = (visibilityCounts[visibility] ?? 0) + 1;

                        for (const topic of repo.topics || []) {
                            topicCounts[topic] = (topicCounts[topic] ?? 0) + 1;
                        }
                    }

                    const topLanguages = Object.entries(languageCounts)
                        .sort((a, b) => b[1] - a[1])
                        .slice(0, 10)
                        .map(([name, count]) => ({ name, count }));

                    const topTopics = Object.entries(topicCounts)
                        .sort((a, b) => b[1] - a[1])
                        .slice(0, 15)
                        .map(([name, count]) => ({ name, count }));

                    const normalizedRepos = filteredRepos.map((repo) => ({
                        name: repo.name,
                        fullName: repo.full_name,
                        private: Boolean(repo.private),
                        visibility: repo.visibility || (repo.private ? "private" : "public"),
                        archived: Boolean(repo.archived),
                        fork: Boolean(repo.fork),
                        language: repo.language || "Unknown",
                        topics: Array.isArray(repo.topics) ? repo.topics : [],
                        description: repo.description || "",
                        defaultBranch: repo.default_branch,
                        stars: Number(repo.stargazers_count ?? 0),
                        forks: Number(repo.forks_count ?? 0),
                        openIssues: Number(repo.open_issues_count ?? 0),
                        updatedAt: repo.updated_at,
                        pushedAt: repo.pushed_at,
                        url: repo.html_url,
                    }));

                    const now = new Date();
                    const thirtyDaysAgo = now.getTime() - 30 * 24 * 60 * 60 * 1000;
                    const activeLast30d = normalizedRepos.filter((repo) => {
                        if (!repo.pushedAt) return false;
                        const pushedAt = new Date(repo.pushedAt).getTime();
                        return Number.isFinite(pushedAt) && pushedAt >= thirtyDaysAgo;
                    }).length;

                    return {
                        status: "success",
                        output: {
                            organization: org,
                            scannedAt: now.toISOString(),
                            scanLimits: {
                                maxRepos,
                                includeArchived,
                            },
                            totals: {
                                reposReturnedByApi: repos.length,
                                reposAnalyzed: normalizedRepos.length,
                                activeLast30d,
                                archived: normalizedRepos.filter((repo) => repo.archived).length,
                                forks: normalizedRepos.filter((repo) => repo.fork).length,
                            },
                            visibility: visibilityCounts,
                            topLanguages,
                            topTopics,
                            repos: normalizedRepos,
                        },
                    };
                },
            },
        ];

        return tools;
    },
};
